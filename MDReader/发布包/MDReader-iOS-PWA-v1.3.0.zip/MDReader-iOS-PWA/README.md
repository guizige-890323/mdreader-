# MD Reader · iOS / iPadOS 主屏幕版（PWA）

> 这个包是 iOS 能力范围内**最接近「桌面图标」**的形态。
> **iOS 不允许第三方注册 `.md` 系统默认打开程序**，也不存在"桌面"，
> 因此本包不提供、也不可能提供默认关联。详见仓库 `docs/PLATFORM.md`。

## 能做什么 / 不能做什么

| 能力 | iOS / iPadOS（本包） |
| --- | --- |
| 主屏幕图标、全屏启动、无 Safari 地址栏 | ✅ 添加到主屏幕后 |
| 离线渲染 Markdown、表格排序、Mermaid | ✅（HTTPS 托管时由 Service Worker 缓存） |
| 从「文件」App 选一份 `.md` 打开 | ✅ 应用内点「打开文件」 |
| 「共享 → 用其他应用打开」接收 md | ❌ 需原生 SwiftUI 工程声明 UTI |
| 双击 `.md` 自动用本程序打开 | ❌ 系统层面不允许 |
| 设为 `.md` 默认打开程序 | ❌ 系统层面不允许 |

## 三步用起来

1. 解压本包，在解压目录起一个静态服务：

   ```bash
   cd MDReader-iOS-PWA
   python -m http.server 8000 --bind 0.0.0.0
   ```

   查电脑局域网 IP（Windows：`ipconfig`，看「IPv4 地址」，如 `192.168.1.20`）。
   手机和电脑连同一个 Wi-Fi；不用外网、不用云服务，文档不会离开局域网。

2. iPhone / iPad 用 **Safari** 打开 `http://192.168.1.20:8000/`
   → 点底部「分享」→ **添加到主屏幕** → 确认。

3. 主屏幕出现「MD Reader」图标，点开是全屏应用。要看文档时点应用内**打开文件**，
   从「文件」App 里选 `.md`（每次需手动选，这是 iOS 的限制）。

> 如果托管在 **HTTPS** 站点（或 localhost），`sw.js` 会自动把整站缓存下来，
> 之后断网也能打开；普通局域网 HTTP 下浏览器不允许 Service Worker，需保持服务可达。

## 应用图标（本包默认卡通组：黑白 + 红耳机 + 蓝眼睛）

| 文件 | 尺寸 | 用途 |
| --- | --- | --- |
| `apple-touch-icon.png` | 180×180 | iPhone 主屏（60pt @3x） |
| `apple-touch-icon-167.png` | 167×167 | iPad Pro 主屏（83.5pt @2x） |
| `apple-touch-icon-152.png` | 152×152 | iPad 主屏（76pt @2x） |
| `apple-touch-icon-120.png` | 120×120 | iPhone 主屏（60pt @2x）／设置里的小图标 |
| `icon-192.png` / `icon-512.png` | 192 / 512 | PWA manifest 标准图标 |
| `icon-maskable-512.png` | 512×512 | 自适应图标，主体收进中心安全区 |
| `icon-1024.png` | 1024×1024 | 高分辨率源图，便于自行裁切 |
| `favicon-16.png` / `favicon-32.png` / `favicon.ico` | 16 / 32 / 多尺寸 | 浏览器标签页与地址栏 |

主屏图标固定用**默认卡通组的黑底版**（黑底 + 白 MD + 红耳机 + 蓝眼睛），
四周留浅色底板，深浅壁纸上都能看清。应用内部（欢迎页 / 侧栏 / 标签页 favicon）
的 LOGO 则完全动态：在「系统设置 → 应用图标」可选**极简**（纯黑白）或**卡通**（黑白红蓝），
每组都有明/暗两版，随浅色 / 深色 / 护眼主题自动切换；偏好会记忆，下次打开沿用。
> iOS 系统限制：主屏图标在「添加到主屏幕」时固化，无法跟随应用内设置动态变化，
> 因此本包的主屏图标固定为默认卡通款；应用内切换不影响它。

> 已经添加过主屏幕的用户：iOS 会缓存旧图标，需要**长按删除主屏图标 →
> 重新「添加到主屏幕」**才会看到新图标。Service Worker 缓存名已升到 `v13`
> 且页面改为 network-first，正常刷新即可拿到新版页面（含新增的「语言 / Language」设置）。

## 界面语言

本包为国内版，默认**简体中文**；在「系统设置 → 通用 / General → 语言 / Language」
可切换到 **English** 或 **其他 / Other（跟随系统）**，偏好会记忆。英文模式下界面全英，
但**你自己打开的 .md 文档不会被翻译**。如需默认英文的国际化版本，用
`python src/build.py --edition global` 重新构建即可。

## 与桌面版的关系

- **Windows 安装版**：桌面图标 + 开始菜单 + 4 种扩展名注册，可设为默认 → `MD Reader Setup 1.3.0.exe`
- **macOS 安装版**：Dock / 应用程序 + `CFBundleDocumentTypes` → 在 Mac 上执行 `desktop/scripts/build-mac.sh`
- **便携版**：`MDReader-Windows11便携版.zip`，解压即用
- 三者与本包共用**同一份** `MDReader.html`，渲染功能完全一致

---
*v1.4 · 2026-11-15 · MD Reader iOS 可行范围包 · 新增云晰柔光与字阶层级修正*

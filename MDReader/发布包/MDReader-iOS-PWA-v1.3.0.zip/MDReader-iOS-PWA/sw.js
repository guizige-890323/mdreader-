/* 仅在 HTTPS / localhost 生效，用于把整站缓存下来离线可用。
   v3：换默认卡通品牌图标后必须换缓存名，否则旧的 Service Worker 会继续吐旧图标。
   v4：新增国际化界面（语言设置）后升缓存名，确保已装用户拿到新版页面。
   v5：卡片序号徽章改为跟随表格配色且高度统一，样式大改必须换缓存名。
   v6：导出下拉补回 Word，恢复四种格式，菜单与字典变更必须换缓存名。
   v7：内置示例重写为「使用指南 · 功能导览」，内容大改必须换缓存名。
   v8：Word 导出图片/表格适配 A4 版心、流程图长节点自动竖向、新增 4 套流程图风格。
   v9：新增「创建 MD / 剪贴板快速粘贴」与四类图表艺术化重绘（玫瑰图、渐变柱、平滑折线、面积趋势）。
   v10：饼图重设计为零描边圆角环形图（拆分出独立「玫瑰」类型），图表区样式大改必须换缓存名。
   v11：剪贴板浮层状态机重写（按钮不再失灵、二次授权可重试），预览逻辑变更必须换缓存名。
   v13：顶栏分组重排（渲染控件移到右侧、导出紧跟保存），DOM 结构改动必须换缓存名。
   v14：玫瑰图改为外标签 + 同色引导线（每片一根线牵到图外），图表 DOM/样式大改必须换缓存名。 */
const CACHE = 'mdreader-pwa-v18';
const ASSETS = ['./', './index.html', './manifest.webmanifest',
                './favicon-16.png', './favicon-32.png',
                './icon-192.png', './icon-512.png', './icon-1024.png',
                './icon-maskable-512.png',
                './apple-touch-icon.png', './apple-touch-icon-120.png',
                './apple-touch-icon-152.png', './apple-touch-icon-167.png'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(
    ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  /* 页面走 network-first：改版后能立刻拿到新 HTML / 新图标；断网才回落缓存 */
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then(r => {
      const copy = r.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
      return r;
    }).catch(() => caches.match(e.request).then(hit => hit || caches.match('./index.html'))));
    return;
  }
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)));
});

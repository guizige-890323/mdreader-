# -*- coding: utf-8 -*-
"""打包国际版便携包：dist-intl 运行文件 + src 完整源码 + 英文 README。

与 src/pack.py 保持同样的清洁策略（跳过隐藏目录、_ 前缀临时文件、__pycache__），
区别只在于运行目录用 dist-intl（英文示例文档 = Sample Document.md），
并多放一份 MDReader-International/README.txt 说明如何回到中文。
"""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist-intl"
SRC = ROOT / "src"
OUT = ROOT.parent / "MDReader-International-便携版.zip"
TOP = "MDReader"

README = """MD Reader - International Edition (English default)

Open dist/MDReader.html in a browser, or double-click the launcher.
The UI starts in English. Switch back to Simplified Chinese in
Settings -> General -> Language. Your own .md files are never translated.

What's new in this build
------------------------
- Create MD: a new "Create MD" button opens a blank document, or one-click
  pastes Markdown copied from an AI chat (hover the button to see a preview).
  Ctrl+S saves it as a real .md file.
- Charts are redrawn after the ECharts gallery, all four types:
  bar (vertical gradient + rounded caps + value labels),
  line (smooth curve + hollow markers),
  trend (gradient area),
  pie (Nightingale rose: equal angles, variable radius, rounded sectors,
  center total and a share legend on the right).
- Charts, chart type and chosen type survive theme/font changes and tab
  switches per document.

Flowchart STRUCTURE (new): Settings > Flowchart Structure picks how the diagram is laid out,
independently of its colour theme. 25 looks = 5 structures x 5 styles.
  - Auto        adaptive pick (converging -> pipeline, deep/bushy -> mind map,
                shallow tree -> org chart; explicit RL/BT keeps the pipeline direction)
  - Pipeline    layered stages, one colour band per stage, numbered badges, bezier spine
  - Mind map    root centred, children radiate by subtree weight, no numbering
  - Org chart   top-down equal-width boxes joined by orthogonal elbow connectors
  - Timeline    horizontal axis, cards alternating above and below
Flowchart STYLE: Classic / Minimal / Business / Vivid / Neon (Settings > Flowchart Style).
  Styles change colour and strokes only; they never redraw the layout.
Word export scales charts and flowcharts to the A4 text area; long flowchart nodes go vertical.
Export formats: Word (.doc) / HTML / PDF / Markdown.

Built with: python src/gen-demo.py && python src/build.py --edition global --out dist-intl/MDReader.html
"""

SKIP_SUFFIX = {".pyc"}

# dist-intl 只放构建产物（MDReader.html + 英文示例），
# 其余运行所需文件（assets / 启动脚本 / 使用说明）从国内版 dist 原样补齐，
# 保证两个便携包「除示例文档与 HTML 本体外完全等价」。
SHARED = ["assets", "open-with.ps1", "使用说明.md", "启动 MDReader.bat", "用此程序打开MD.bat"]


def skip(rel):
    return (any(p.startswith(".") for p in rel.parts)
            or rel.name.startswith("_")
            or rel.suffix in SKIP_SUFFIX
            or "__pycache__" in rel.parts)


with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for base, prefix in ((DIST, "dist"), (SRC, "src")):
        for f in sorted(base.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(base)
            if skip(rel):
                continue
            z.write(f, TOP + "/" + prefix + "/" + rel.as_posix())
    # 补齐 dist-intl 里没有的公共运行文件
    for name in SHARED:
        src = ROOT / "dist" / name
        if src.is_dir():
            for f in sorted(src.rglob("*")):
                if f.is_file() and not skip(f.relative_to(src)):
                    z.write(f, TOP + "/dist/" + f.relative_to(ROOT / "dist").as_posix())
        elif src.is_file():
            z.write(src, TOP + "/dist/" + name)
    z.writestr("MDReader-International/README.txt", README)

print("packed:", OUT)
print("size  : %.2f MB" % (OUT.stat().st_size / 1024 / 1024))
with zipfile.ZipFile(OUT) as z:
    names = z.namelist()
print("files :", len(names))
for n in names:
    if n.startswith("MDReader/dist/") or "README" in n:
        print("  ", n)
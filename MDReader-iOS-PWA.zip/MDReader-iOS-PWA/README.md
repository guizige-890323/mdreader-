# MD Reader · iOS / iPadOS 主屏幕版（PWA）

> 这个包是 iOS 能力范围内**最接近「桌面图标」**的形态。
> **iOS 不允许第三方注册 `.md` 系统默认打开程序**，也不存在"桌面"，
> 因此本包不提供、也不可能提供默认关联。详见仓库 `docs/PLATFORM.md`。

## 能做什么 / 不能做什么

| 能力 | iOS / iPadOS（本包） |
| --- | --- |
| 主屏幕图标、全屏启动、无 Safari 地址栏 | ✅ 添加到主屏幕后 |
| 离线渲染 Markdown、表格排序、Mermaid | ✅（HTTPS 托管时由 Service Worker 缓存） |
| 从「文件」App 选一份 `.md` 打开 | ✅ 应用内点「打开文件」 |
| 「共享 → 用其他应用打开」接收 md | ❌ 需原生 SwiftUI 工程声明 UTI |
| 双击 `.md` 自动用本程序打开 | ❌ 系统层面不允许 |
| 设为 `.md` 默认打开程序 | ❌ 系统层面不允许 |

## 三步用起来

1. 解压本包，在解压目录起一个静态服务：

   ```bash
   cd MDReader-iOS-PWA
   python -m http.server 8000 --bind 0.0.0.0
   ```

   查电脑局域网 IP（Windows：`ipconfig`，看「IPv4 地址」，如 `192.168.1.20`）。
   手机和电脑连同一个 Wi-Fi；不用外网、不用云服务，文档不会离开局域网。

2. iPhone / iPad 用 **Safari** 打开 `http://192.168.1.20:8000/`
   → 点底部「分享」→ **添加到主屏幕** → 确认。

3. 主屏幕出现「MD Reader」图标，点开是全屏应用。要看文档时点应用内**打开文件**，
   从「文件」App 里选 `.md`（每次需手动选，这是 iOS 的限制）。

> 如果托管在 **HTTPS** 站点（或 localhost），`sw.js` 会自动把整站缓存下来，
> 之后断网也能打开；普通局域网 HTTP 下浏览器不允许 Service Worker，需保持服务可达。

## 与桌面版的关系

- **Windows 安装版**：桌面图标 + 开始菜单 + 4 种扩展名注册，可设为默认 → `MD Reader Setup 1.3.0.exe`
- **macOS 安装版**：Dock / 应用程序 + `CFBundleDocumentTypes` → 在 Mac 上执行 `desktop/scripts/build-mac.sh`
- **便携版**：`MDReader-Windows11便携版.zip`，解压即用
- 三者与本包共用**同一份** `MDReader.html`，渲染功能完全一致

---
*v1.3 · 2026-11-11 · MD Reader iOS 可行范围包*
